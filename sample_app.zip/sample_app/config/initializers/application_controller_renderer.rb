# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ff838d205d21b498da2a7c31ef098a13346cec548eb8e9ecf58c0cd939f2412eaf89810aa8cf7ae707300078723cfe83cf412c14fde494ecacd0ac87ed2891b0'